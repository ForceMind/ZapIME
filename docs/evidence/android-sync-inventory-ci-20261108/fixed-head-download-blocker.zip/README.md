# PR #104 — 16c7d89 attempt 1 外部下载阻塞证据

状态截点：**2026-11-09 07:40:15 UTC**。该 head 的 8 条工作流已全部结束，结果为
**3 success、5 failure**。23 个 GitHub job 节点中 **6 success、11 failure、6 skipped**。
11 个失败明确分为 **6 个上游 HTTP 504 下载失败**和 **5 个下游缺失构建产物失败**。
矩阵尚未展开时 GitHub 以一个带 `matrix.api` 的 skipped 节点呈现；这里按 API 返回的 job 节点计数。

[PR #104](https://github.com/ForceMind/ZapIME/pull/104) 在截点仍为 open draft，
head `16c7d89ff7faa6c3b4979074ed9301cf25be9544`，未合并。本轮没有重跑任何 job。

## 固定源码与实际 checkout

| 身份 | SHA |
| --- | --- |
| 本地 fixture 修复提交 | `72ddf646b8cc3dd9db1b819891aa5cda8cb0d536` |
| 发布后的 PR head | `16c7d89ff7faa6c3b4979074ed9301cf25be9544` |
| 两者完全相同的 branch tree | `a6f1e6160edb3763859d62583d63e9f5f22dbd88` |
| 实际 CI checkout | `4c182b24347d08c2008863a29f369a7089eaeca2` |
| 实际 CI tree | `a73b74ca12b199c282fc8afc55256e6d0578753b` |

发布 commit 的唯一 parent 为 `d6f98a8`。3 个变更 blob 逐一比对，tree 读回一致，
ref 更新使用 expected SHA 与 `force=false`。实际 checkout 的 parents 是
main `a199d5658f1e071059b4c4b9bd2db02c381c188f` 与 PR head `16c7d89`，
包含 main 文档合入，所以 CI tree 与 branch tree不同。15 份保留日志均记录了该实际 checkout SHA；
GitHub Git data API 核对了 tree 与 parents。失败构建没有生成 build metadata 或新的可交付 APK。

## 工作流结果

| 工作流 | Run ID | 最终结论 |
| --- | --- | --- |
| Offline speech CPU probe | 42579960285 | success |
| Source Alpha release | 42579960234 | success；发布 job skipped |
| Independent ciphertext sync service | 42579960236 | success |
| VoiceKey Android model acceptance (focused) | 42579960224 | failure；资源下载失败，runtime 依赖跳过 |
| Windows native TSF development | 42579960295 | failure；资源下载失败 |
| Offline candidate ranking acceptance | 42579960257 | failure；两个构建/host 下载失败，runtime 依赖跳过 |
| Android native input acceptance | 42579960293 | failure；构建失败后 5 个依赖缺失 artifact |
| ZapIME development checks | 42579960239 | failure；Shared core 三平台成功，Apple native 下载失败 |

`workflow-snapshot.json` 含全部 23 个 job 的实际最终状态、失败步骤、run 链接与截点。
`failure-classification.json` 提供逐 job 分层，不能把其中的 skipped 或 missing artifact 当成新的产品断言失败。

## 上游下载失败与下游连带结果

- `fetch_resources.py`：focused build `129036087555`、Windows TSF `129036087598`、
  Apple native `129036087895` 各执行有界 3 次请求，最终 HTTP 504。
- `prepare_candidate_model.py`：Candidate product `129036087447`、Candidate host
  `129036087802`、full Android build `129036087254` 同样在固定资源下载时耗尽 3 次尝试。
- full Android 后继 5 个 job 的原日志都明确报告
  `Artifact not found for name: ZapIME-Android-development`。
  它们尚未执行应用 instrumentation。
- 6 个 skipped 节点中，5 个是依赖 build 的 runtime/matrix job；1 个为 PR 事件不发布的 Source Alpha publish job。

新 fixture 的 **API28/35/36 schema 2 JNI/Activity 均为 NOT RUN**。新 Candidate API 矩阵、
配置实验、full Android 接受度以及 focused VoiceKey/HTTPS 等依赖构建的运行门禁也未建立新证据。
本轮失败没有证明 fixture 或产品断言错误；它证明实际验收被外部下载阻断。

根代理另用同一个生产 `fetch_resources.fetch`，向其独立空临时目录获取资源，仍在
**87.265 秒**后报告 HTTP 504。原 JSON 按字节保存在 `resource-probe/verification.json`。
该本地探测是当前下载阻塞的旁证，不是 GitHub CI 或 Android 运行验收。
原因定位止于已观测的 HTTP 504；本包没有证据判定具体网关或上游内部根因。

## 确实完成的 Rust 与工具链检查

按原 CI 的每份 `test result: ok` 逐条求和，失败数均为 0：

| Job | Rust 通过数 | fmt | strict clippy |
| --- | ---: | --- | --- |
| Source prepare / 129036086767 | 145 | PASS | PASS |
| Shared core Ubuntu / 129036087881 | 145 | PASS | PASS |
| Shared core macOS / 129036087505 | 145 | PASS | PASS |
| Shared core Windows / 129036087799 | 142 | PASS | PASS |

source job 实际执行 Rust 1.97.1 的 `fmt --all --check`、
`test --workspace --locked`、`clippy --workspace --all-targets --locked -- -D warnings`。
Shared core 三平台也逐项执行并成功。Windows 少的 3 项已按 test 名和源码核对，
均带 `#[cfg(unix)]`（两个 sync writer 路径/软链用例和一个 workspace 软链用例）。
`validation-observed.json` 留有命令、计数和原结果行；对应完整日志在 `logs/validation/`。
这些结果不能代替 Android JNI/Activity 或手机验收。

## 原件与复核

`logs/failures/` 保存全部 11 个失败 job 的完整 connector 日志文本（UTF-8 gzip）；
`logs/validation/` 保存以上 4 个成功 job 的完整日志。没有截断为成功片段。
各 job 的原状态与失败类型独立记录，后续恢复或成功不会覆盖它们。

`SHA256SUMS` 覆盖包内每个保留文件，可在根目录执行：

```sh
sha256sum -c SHA256SUMS
```

本包不含 APK 或模型权重。前一 head `d6f98a8` 的 API28 fixture 失败、
Candidate API36 未明触摸/重启失败和 full API35 ADB 准备失败，保留在独立的
`pr104-d6f98a8-attempt1-evidence` 包中；本次 fixture 修复与持续下载阻塞不改变那些原始结论。

