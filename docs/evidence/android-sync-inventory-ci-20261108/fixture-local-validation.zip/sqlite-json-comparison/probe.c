#include <stdio.h>
#include "sqlite3.h"
static int check(sqlite3 *db,const char *label,const char *sql){
 char *error=0;int rc=sqlite3_exec(db,sql,0,0,&error);
 printf("%s rc=%d message=%s\n",label,rc,error?error:"OK");sqlite3_free(error);return rc;
}
int main(int argc,char **argv){
 if(argc!=2)return 2;
 printf("sqlite_version=%s json_omitted=%d\n",sqlite3_libversion(),sqlite3_compileoption_used("OMIT_JSON"));
 sqlite3 *db=0;int rc=sqlite3_open_v2(argv[1],&db,SQLITE_OPEN_READONLY,0);if(rc)return 3;
 int r=check(db,"readonly_records_snapshot","SELECT * FROM records ORDER BY 1");
 r|=check(db,"readonly_operation_snapshot","SELECT * FROM operations ORDER BY 1");sqlite3_close(db);
 if(r)return 4;
 rc=sqlite3_open_v2(argv[1],&db,SQLITE_OPEN_READWRITE,0);if(rc)return 5;
 int w=check(db,"write_records_with_expression_index","INSERT INTO records VALUES('00000000-0000-0000-0000-000000000001',1,'{\"id\":\"00000000-0000-0000-0000-000000000001\",\"revision\":1,\"deleted\":false,\"content\":{\"type\":\"favorite\",\"title\":\"synthetic\",\"text\":\"synthetic\"}}')");sqlite3_close(db);
 return sqlite3_compileoption_used("OMIT_JSON")?(w==SQLITE_ERROR?0:6):(w==SQLITE_OK?0:7);
}
