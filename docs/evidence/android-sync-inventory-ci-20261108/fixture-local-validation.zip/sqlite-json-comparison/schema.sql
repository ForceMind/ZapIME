CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY, revision INTEGER NOT NULL, body TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS operations(id TEXT PRIMARY KEY, request TEXT NOT NULL, result TEXT NOT NULL, pending INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS sync_queue(sequence INTEGER PRIMARY KEY AUTOINCREMENT,operation_id TEXT UNIQUE NOT NULL REFERENCES operations(id));
            CREATE TRIGGER IF NOT EXISTS queue_new_operation AFTER INSERT ON operations BEGIN INSERT INTO sync_queue(operation_id) VALUES(NEW.id); END;
            CREATE TABLE IF NOT EXISTS sync_uploads(operation_id TEXT PRIMARY KEY REFERENCES operations(id),wire TEXT NOT NULL,ack_revision INTEGER);
            CREATE TABLE IF NOT EXISTS sync_versions(record_id TEXT PRIMARY KEY,server_revision INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS sync_received(operation_id TEXT PRIMARY KEY,server_revision INTEGER UNIQUE NOT NULL,fingerprint TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS sync_pending_record ON operations(pending,json_extract(result,'$.id'));CREATE INDEX IF NOT EXISTS panel_order ON records(json_extract(body,'$.deleted'),COALESCE(json_extract(body,'$.content.pinned'),0) DESC,json_extract(body,'$.content.type'),COALESCE(json_extract(body,'$.content.expires_at_ms'),0) DESC,CASE json_extract(body,'$.content.type') WHEN 'snippet' THEN json_extract(body,'$.content.code') WHEN 'favorite' THEN json_extract(body,'$.content.title') ELSE '剪贴板' END,id);
