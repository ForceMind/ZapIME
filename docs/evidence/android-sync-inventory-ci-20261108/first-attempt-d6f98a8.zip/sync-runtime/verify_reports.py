#!/usr/bin/env python3
"""Replay exact 4ed8ca0 / d6f98a8 schema validators on retained CI reports."""
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "validator-snapshot"))
from android_sync_preparation_report import verify_report as preparation, verify_ui_report as recovery_ui
from android_sync_key_report import verify_report as key_registration
from android_sync_transfer_report import verify_report as transfer
from android_sync_pages_report import verify_report as pages

def unique(items):
    value = {}
    for key, item in items:
        if key in value:
            raise ValueError("Duplicate JSON key: " + key)
        value[key] = item
    return value

def read(path):
    return json.loads(path.read_text(), object_pairs_hook=unique)

def require(condition, detail):
    if not condition:
        raise AssertionError(detail)

validators = [
    ("sync-preparation-report.json", preparation),
    ("sync-preparation-ui-report.json", recovery_ui),
    ("sync-key-registration-report.json", key_registration),
    ("sync-transfer-report.json", transfer),
    ("sync-pages-ui-report.json", pages),
]
apis = [int(x) for x in sys.argv[1:]] or [28, 35, 36]
results = []
for api in apis:
    path = ROOT / ("api" + str(api))
    for name, validator in validators:
        entry = {"api": api, "file": name}
        try:
            report = read(path / name)
            entry.update(schema_version=report.get("schema_version"), reported_status=report.get("status"),
                         observed_cases=len(report.get("cases", [])),
                         observed_passed_cases=sum(row.get("passed") is True for row in report.get("cases", [])))
            validator(report, api)
            entry["status"] = "PASS"
        except Exception as error:
            entry.update(status="FAIL", error=type(error).__name__ + ": " + str(error))
        results.append(entry)
    entry = {"api": api, "file": "offline-uid.json / instrumentation.txt / runtime logs"}
    try:
        uid = read(path / "offline-uid.json")
        require(uid.get("package") == "org.zapime.android", "Wrong UID package")
        require(type(uid.get("uid")) is int and uid["uid"] >= 10000, "Invalid application UID")
        require(all(uid.get(key) is True for key in ("ipv4_reject", "ipv6_reject", "removed")),
                "Incomplete exact-UID network rejection or cleanup")
        entry["uid_cleanup"] = "PASS"
        log = (path / "instrumentation.txt").read_text()
        require("PASS Android local sync preparation acceptance" in log
                and "INSTRUMENTATION_CODE: -1" in log
                and "FAIL Android voice" not in log and "INSTRUMENTATION_FAILED" not in log,
                "Instrumentation did not pass")
        for name in ("crash.txt", "activity-errors.txt"):
            text = (path / name).read_text()
            require(not ("org.zapime.android" in text and any(marker in text for marker in (
                "FATAL EXCEPTION", "Fatal signal", "ANR in org.zapime.android"))),
                "Product crash or ANR in " + name)
        entry["status"] = "PASS"
    except Exception as error:
        entry.update(status="FAIL", error=type(error).__name__ + ": " + str(error))
    results.append(entry)
summary = {
    "repository": "ForceMind/ZapIME", "pr": 104, "run_id": 42577078955, "run_attempt": 1,
    "head_commit": "d6f98a8025aae4025583ed6577a23e1a580c7fb5",
    "tested_checkout": "e6bf431fe2c8a7e719d5564a41817c1ef833fb3a",
    "tested_tree": "88646a7442ae6941282ff06e30237b67797fe781",
    "validator_local_commit": "4ed8ca0da1ff2474af57123cd5b7b48ea3a480e8",
    "scope": "Synthetic Android x86_64 emulators; replay of retained reports, not a new runtime execution.",
    "results": results,
    "passed": all(row["status"] == "PASS" for row in results),
}
output = ROOT / ("verification-" + "-".join(str(x) for x in apis) + ".json")
output.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(summary, ensure_ascii=False))
sys.exit(0 if summary["passed"] else 1)

