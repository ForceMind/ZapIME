# PR #104 — d6f98a8 首轮 CI 原始证据

本包固定记录 `d6f98a8025aae4025583ed6577a23e1a580c7fb5` 的 attempt 1。
8 条工作流全部完成：**5 条成功、3 条失败**。29 个 job 中 25 个成功、3 个失败、1 个发布 job 按 PR 事件跳过。
后续新提交、重建或成功结果不能覆盖本轮失败；本包不是“全部验收通过”的证明。

## 源码身份

| 身份 | SHA |
| --- | --- |
| 审查后的本地提交 | `4ed8ca0da1ff2474af57123cd5b7b48ea3a480e8` |
| GitHub 发布提交 | `d6f98a8025aae4025583ed6577a23e1a580c7fb5` |
| 实际 CI checkout | `e6bf431fe2c8a7e719d5564a41817c1ef833fb3a` |
| 三者完全相同的 tree | `88646a7442ae6941282ff06e30237b67797fe781` |

实际 checkout 的 parents 是 main `88112f4` 与 PR head `d6f98a8`。
Candidate 和 focused 的原始 build metadata 都记录该 checkout；上传时核对了 23 个 blob 及远程 tree。
main 后续文档合并到 `a199d56` 不改变本轮测试身份。完整 SHA、远程校验和产物链分别在
`source-identity.json`、`upload-receipt.json` 和 `build-metadata/`。

## 三种失败分层

### 1. 新 schema 2 的 API28 fixture 失败

[Focused run 42577078955](https://github.com/ForceMind/ZapIME/actions/runs/42577078955)
中的 API28 job `129030796457` 在 `fresh_main_prepared_fixture` 报告
`SQLiteException`，`failure_substep=case_body`。还未进入新的 Activity 分页场景。

| API | preparation | recovery UI | key registration | transfer schema 2 | pages schema 2 | 原 instrumentation |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| 28 | 11 PASS | 10 PASS | 14 PASS | 15 PASS | 首项失败；12 项未完整通过 | FAIL |
| 35 | 11 PASS | 10 PASS | 14 PASS | 15 PASS | 12 PASS | PASS |
| 36 | 11 PASS | 10 PASS | 14 PASS | 15 PASS | 12 PASS | PASS |

三 API 的 exact-UID IPv4/IPv6 拦截与清理证据都通过。API35/36 各 62 项通过；
API28 只有前 50 项通过。三个 transfer 报告均实际覆盖只读 JNI inventory，
但 API28 的 Activity 验收仍缺失。

固定源码的严格 validator 逐份重放结果在 `sync-runtime/verification-28-35-36.json`。
新增 fixture 使用 Android framework SQLite 写入带 `json_extract` 表达式索引的 Rust 数据库，
因此平台 SQLite 功能差异是待验证的解释。原始报告和 job log 未保留具体 SQLite 错误文本，
不能把某一条精确 SQL 错误写成已观测事实。

### 2. Candidate API36 系统 IME 输入失败

[Candidate job 129029859606](https://github.com/ForceMind/ZapIME/actions/runs/42577078987/job/129029859606)
的 method 阶段通过，系统 IME 阶段在 `touch_pinyin_1` 失败：
`touch_key_not_observed_in_editable`。编辑器仅保留已提交的合成“你好”，没有预编辑。
退出、系统键盘恢复、UID 和设置清理均完成；保留证据未见 ANR 或遮挡窗口。

framework restart 与第六次键输入的尝试接近，但缺少 DOWN/UP、click、dispatch 时间点，
所以具体因果仍未确认。method 通过、清理通过或未来一次通过都不能覆盖本次真实系统输入失败。
本切片没有修改对应 IME/touch/独立 host 核心文件；也不能由此宣称这条既有生命周期问题已修复。
`candidate-api36/` 保留原 ZIP、完整压缩 job log、诊断与独立 review JSON。
独立 review 内的原工作区路径是审查时来源记录；原件已按字节归档。

### 3. Full Android API35 的 ADB/root 准备失败

[Full Android job 129031760719](https://github.com/ForceMind/ZapIME/actions/runs/42577078966/job/129031760719)
在 emulator 开机、APK 安装成功后，进入 `offline_product` 的第一条
`adb -s emulator-5554 root` 返回 1。此时尚未执行应用 instrumentation，也没有 acceptance artifact。
这是测试环境准备失败，不能记为应用断言失败或应用验收通过。stderr/stdout 被原脚本捕获且未打印，
具体 root 失败原因未知。原始 job log 与元数据在 `full-api35/`。

## 完整工作流结论

`workflow-final.json` 保存本轮全部 8 条工作流与 29 个 job 的最终状态。
full API36、full/focused VoiceKey 三 API 均成功；Candidate API28/35 和配置 API35 成功。
Source Alpha 仅 archive gate 成功，发布 job 为 skipped；本轮没有发布 Release。

## 复核方法与包边界

`artifact-manifest.json` 记录下载原 ZIP 的 artifact ID、字节数与 GitHub SHA256 digest；
下载后逐一校验。三个 sync 原 ZIP、Candidate API36 失败原 ZIP均保留原字节。
原 ZIP 内可能包含合成测试截图；本包不含 APK、模型权重或用户数据。

`sync-runtime/validator-snapshot/` 来自固定本地提交的原始 Git blob，含其纯报告校验所需依赖。
可以执行：

```sh
sha256sum -c SHA256SUMS
PYTHONDONTWRITEBYTECODE=1 python3 sync-runtime/verify_reports.py 28 35 36
```

第二条命令预期退出码为 1，因为本轮 API28 的 pages 报告确实失败；它不会重新运行 Android。
只复核 API35/36 可传入 `35 36`，应退出 0。所有运行证据均为合成的 x86_64 emulator 场景，
不能扩展为真实手机、ARM64 运行、自然语音或 #77 完整首次上传的验收。

