#!/usr/bin/env python3
"""Offline replay of retained API36 reports; never imports a device runner.

Reads the downloaded ZIP, original evidence and hash-pinned local source. Writes
only verification.json and verification-output.txt beside this script. No ADB,
network, subprocess, product installation, fixture clearing or source mutation.
"""
import argparse
import ast
import hashlib
import json
import re
import sys
import textwrap
import zipfile
from pathlib import Path, PurePosixPath


RUN = 44534343888
JOB = 135606193452
ARTIFACT = 14537791631
HEAD = "60beadee4af411541fc716fbb3bc0eb74b769591"
CHECKOUT = "95d93e4b6fc2dbd51cb4e2446d705c54a9166f33"
TREE = "d4b891619c7a162e0d60db230bfadaed2b419c84"
ZIP_BYTES = 2860064
ZIP_SHA = "2589fea6c94fbd6f2a3b76041691cb691e572dfaf30b0a0a985b81e690622366"
SOURCE_HASHES = {
    "scripts/android_voice_smoke.py": "bae9d089bd8031633aa85e2dd1d55e20b24cb57399884572f8a35d37b2859dfd",
    "scripts/android_voicekey_model_smoke.py": "45992cf26a4b651065a5fdca69cb60ff3b6e46fc7f8e7451a37f6cdd77af5a42",
    "scripts/android_sync_preparation_report.py": "9d51c00792b17e9bb6f1da378adf982d4410d4ee2eea6ff29672255256bfc82b",
    "scripts/android_smoke_repeat.py": "16fb0c67cdd1a21d4d8be61fba65ee72504e06278315cf3da2a2ecc4f2a5d730",
    "scripts/android_smoke.py": "24b92d87624d3352dffbed40cf5232f6ed54ee164b1d25c2f28a1c04a11a00cc",
    "scripts/android_ci_device.py": "4b89868d14cb10c5b2029c8f89bcc1a8e00101f96169d658ab18367cb533cb12",
    "scripts/android_acceptance.py": "3b6abb0173938085bf50dc95d3805c0beef46482469b8d9877dd1a4f0c4e3043",
    "scripts/android_offline_uid.py": "6378369688de0fc0ca7f01d1f3bdb7d3b5f640b0c37ccf4081a690fc882477f0",
    "platforms/android/tests/java/org/zapime/android/test/SmokeInstrumentation.java": "5aea879688a8274904b3bcee43d1acf5c8508e7ca1f8f2436f0816425a8a6dd6",
    "platforms/android/tests/java/org/zapime/android/test/ToolsPanelObservation.java": "f73814e1f1e6a514a6365243f91423bb45e0cd620cb5903044a078ddb4be64e6",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_text(path):
    return path.read_text(encoding="utf-8")


def no_instrumentation_failure(text):
    return "FAIL" not in text and "INSTRUMENTATION_FAILED" not in text


def safe_compile(nodes, label, namespace):
    """Compile ONLY reviewed pure predicates extracted from pinned sources."""
    module = ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[]))
    names = {
        "any", "dict", "frozenset", "int", "isinstance", "len", "list",
        "set", "str", "type", "ValueError", "SystemExit",
        "verify_permission_cases", "verify_boundary_report", "verify_sync_preparation",
    }
    for node in ast.walk(module):
        require(not isinstance(node, (ast.Import, ast.ImportFrom, ast.Global, ast.Nonlocal)),
                "Non-pure validator syntax: " + label)
        if isinstance(node, ast.Call):
            allowed = (isinstance(node.func, ast.Name) and node.func.id in names or
                       isinstance(node.func, ast.Attribute) and node.func.attr in
                       {"get", "loads", "read_text"})
            require(allowed, "Unexpected validator call: " + label)
    exec(compile(module, label, "exec"), namespace)


def pure_validators(sources, voice_dir):
    # The full runner modules contain top-level ADB/cleanup operations. None is
    # imported or executed. These functions and this contiguous JSON-only block
    # have been read, pinned and checked for a small allowed call vocabulary.
    builtins = {
        "any": any, "dict": dict, "frozenset": frozenset, "int": int,
        "isinstance": isinstance, "len": len, "list": list, "set": set,
        "str": str, "type": type, "ValueError": ValueError, "SystemExit": SystemExit,
    }
    namespace = {"__builtins__": builtins}
    vk = ast.parse(sources["scripts/android_voicekey_model_smoke.py"])
    names = {"verify_permission_cases", "verify_boundary_report"}
    nodes = [n for n in vk.body if isinstance(n, ast.FunctionDef) and n.name in names]
    require(len(nodes) == 2, "Missing pinned VoiceKey/permission predicates")
    safe_compile(nodes, "pinned voice boundary predicates", namespace)
    sync = ast.parse(sources["scripts/android_sync_preparation_report.py"])
    nodes = [n for n in sync.body if
             isinstance(n, ast.FunctionDef) and n.name == "verify_report" or
             isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "CASES"
                                             for t in n.targets)]
    require(len(nodes) == 2, "Missing pinned sync preparation predicate")
    safe_compile(nodes, "pinned local sync predicate", namespace)
    namespace["verify_sync_preparation"] = namespace["verify_report"]
    namespace["json"] = json
    namespace["out"] = voice_dir
    source = sources["scripts/android_voice_smoke.py"]
    begin = source.index('    evidence=json.loads((out/"empty-pcm-report.json").read_text())')
    end = source.index('    method="org.zapime.android/.ZapInputMethodService"', begin)
    block = textwrap.dedent(source[begin:end])
    safe_compile(ast.parse(block).body, "pinned seven-report JSON assertions", namespace)
    namespace["verify_report"](read_json(voice_dir / "sync-preparation-report.json"), api=36)
    return sha(block.encode("utf-8"))


def verify_keyboard_and_exit(directory, teardown_name):
    keyboard = read_json(directory / "system-keyboard.json")
    require(type(keyboard.get("api_level")) is int and keyboard["api_level"] == 36,
            "Wrong API in saved system keyboard proof")
    require(keyboard.get("system_package_verified") is True and
            keyboard.get("source") == "pm list packages -s", "Unverified system keyboard")
    selected = keyboard.get("selected_ime")
    require(isinstance(selected, str) and "/" in selected and
            not selected.startswith("org.zapime.android/"), "No different system keyboard")
    teardown = read_text(directory / teardown_name)
    require("ACTIVITY MANAGER SERVICES" in teardown and "(nothing)" in teardown and
            "ZapInputMethodService" not in teardown, "Retained teardown is not empty")
    activity = read_text(directory / "activity-errors.txt")
    require(re.search(r"ANR in org\.zapime\.android(?:\.|\s|\(|$)", activity) is None,
            "ZapIME/test ANR in retained activity log")
    state_file = directory / "input-method-state.log"
    observed_current_ime = None
    if state_file.exists():
        state = read_text(state_file)
        current_ids = re.findall(r"(?m)^\s*mCurId=(\S+)\s*$", state)
        require(current_ids == [selected], "Current input method differs from selected system keyboard")
        observed_current_ime = selected
    return {"system_keyboard": selected, "system_package_verified": True,
            "observed_current_ime": observed_current_ime,
            "current_ime_dump_available": state_file.exists(),
            "empty_services_observed": True, "no_app_anr": True,
            "system_keyboard_file": str((directory / "system-keyboard.json").relative_to(BASE)),
            "teardown_file": str((directory / teardown_name).relative_to(BASE))}


def verify(base, repository):
    manifest = read_json(base / "download-manifest.json")
    require(manifest.get("repository") == "ForceMind/ZapIME" and
            manifest.get("run_id") == RUN and manifest.get("job_id") == JOB and
            manifest.get("head_sha") == HEAD and manifest.get("observed_checkout_sha") == CHECKOUT and
            manifest.get("observed_tree_sha") == TREE, "Unexpected CI provenance")
    artifact = manifest["artifact"]
    require(artifact.get("id") == ARTIFACT and artifact.get("size_in_bytes") == ZIP_BYTES and
            artifact.get("digest") == "sha256:" + ZIP_SHA and
            manifest.get("zip_bytes") == ZIP_BYTES and manifest.get("zip_sha256") == ZIP_SHA,
            "Unexpected artifact identity")
    archive_bytes = (base / "original-artifact.zip").read_bytes()
    require(len(archive_bytes) == ZIP_BYTES and sha(archive_bytes) == ZIP_SHA,
            "Original ZIP digest/size mismatch")
    members = manifest["files"]
    require(isinstance(members, list) and len(members) == 91, "Expected exactly 91 original files")
    paths = [r["path"] for r in members]
    require(len(set(paths)) == len(paths), "Duplicate original member paths")
    by_path = {r["path"]: r for r in members}
    total = 0
    with zipfile.ZipFile(base / "original-artifact.zip") as archive:
        archived = [i for i in archive.infolist() if not i.is_dir()]
        require(len(archived) == 91 and {i.filename for i in archived} == set(paths),
                "ZIP members differ from raw manifest")
        for name, record in by_path.items():
            pure = PurePosixPath(name)
            require(not pure.is_absolute() and ".." not in pure.parts and "\\" not in name,
                    "Unsafe raw evidence path")
            target = base / name
            require(target.resolve().is_relative_to(base.resolve()) and not target.is_symlink(),
                    "Raw evidence escapes original folder")
            local = target.read_bytes()
            stored = archive.read(name)
            require(len(local) == record["bytes"] and sha(local) == record["sha256"] and
                    stored == local, "Original member byte/hash mismatch: " + name)
            total += len(local)
    sources = {}
    for name, expected in SOURCE_HASHES.items():
        data = (repository / name).read_bytes()
        require(sha(data) == expected, "Pinned validator/source changed: " + name)
        sources[name] = data.decode("utf-8")

    rounds = []
    for number in (1, 2):
        directory = base / f"device-smoke-evidence/{RUN}-1/round-{number}"
        log = read_text(directory / "instrumentation.log")
        marker = "PASS ZapIME native keyboard:"
        require(log.count(marker) == 1 and no_instrumentation_failure(log),
                "Missing complete input PASS or failure present")
        scopes = ("same-editor restart continuity", "real commit", "private field",
                  "nine-key spelling/commit/backspace/shortcut/numeric/privacy",
                  "sensitive clipboard rejection", "focus/restart/no-learning privacy")
        require(all(s in log for s in scopes), "Incomplete final input/privacy acceptance scope")
        runtime = read_text(directory / "runtime-errors.log")
        require(re.search(r"Process: org\.zapime\.android(?:\.test)?,", runtime) is None,
                "Product or test-host runtime fatal")
        host = read_text(directory / "host-lifecycle.txt")
        retained = [line for line in host.splitlines() if "restart_tools_" in line]
        screenshot = directory / "tools.png"
        require(screenshot.read_bytes().startswith(b"\x89PNG\r\n\x1a\n"),
                "Missing original tools screenshot")
        item = {"round": number, "status": "PASS", "full_input_and_privacy": True,
                "tools_restart_required_by_pinned_source": True,
                "tools_observation_events_retained": retained,
                "observed_tools_sample_count": None, "observed_tools_stable_ms": None,
                "tools_screenshot": str(screenshot.relative_to(base)),
                "no_app_runtime_fatal": True,
                "instrumentation_file": str((directory / "instrumentation.log").relative_to(base))}
        item["actual_exit"] = verify_keyboard_and_exit(directory, "ime-teardown.log")
        rounds.append(item)

    voice = base / "voice-android"
    block_sha = pure_validators(sources, voice)
    reports = {}
    report_names = ("empty-pcm-report.json", "voice-commit-report.json", "sync-connection-report.json",
                    "sync-profile-report.json", "sync-preparation-report.json", "local-backup-report.json",
                    "voicekey-boundary-report.json")
    for name in report_names:
        report = read_json(voice / name)
        require(report.get("synthetic") is True and type(report.get("api_level")) is int and
                report["api_level"] == 36 and isinstance(report.get("scope"), str) and report["scope"],
                "Wrong report execution scope: " + name)
        reports[name] = {"status": "PASS", "case_count": len(report["cases"]), "scope": report["scope"]}
    native_log = read_text(voice / "instrumentation.txt")
    cleanup_marker = "PASS installed Android offline voice cleanup and restored local opt-in preference"
    require(cleanup_marker in native_log and "PASS Android offline voice native acceptance" in native_log and
            "INSTRUMENTATION_CODE: -1" in native_log and no_instrumentation_failure(native_log),
            "Missing native voice/installed cleanup PASS")
    ui = read_text(voice / "ui-instrumentation.txt")
    require("PASS ZapIME voice UI:" in ui and "empty_result_insert_checked=true" in ui and
            "INSTRUMENTATION_CODE: -1" in ui and no_instrumentation_failure(ui),
            "Missing actual voice UI/empty-insert PASS")
    crash = read_text(voice / "crash.txt")
    require(not ("org.zapime.android" in crash and
                 ("FATAL EXCEPTION" in crash or "Fatal signal" in crash)), "Voice crash log fatal")
    native = read_json(voice / "native-report.json")
    require(native.get("synthetic") is True and native.get("platform") == "Android emulator" and
            type(native.get("api_level")) is int and native["api_level"] == 36 and
            native.get("abi") == "x86_64" and native.get("model") == "x-asr-streaming-int8-2026-06-05" and
            native.get("configured_cpu_threads") == 2 and native.get("expected_fragments_passed") is True,
            "Wrong native recognition execution evidence")
    require(type(native.get("recognized_codepoints")) is int and native["recognized_codepoints"] > 0 and
            type(native.get("audio_samples")) is int and native["audio_samples"] > 0 and
            abs(native["audio_seconds"] - native["audio_samples"] / 16000) < 1e-9,
            "Inconsistent synthetic PCM/report size")
    for key in ("recognizer_load_ms", "decode_with_jni_ms", "rtf"):
        require(type(native.get(key)) in (int, float) and native[key] >= 0, "Invalid observed metric")
    require(abs(native["rtf"] - native["decode_with_jni_ms"] / 1000 / native["audio_seconds"]) < 1e-9,
            "Inconsistent synthetic decode RTF")
    gates = read_json(voice / "combined-gates.json")
    require(set(gates) == {"android_smoke_repeat.py", "android_voice_smoke.py"} and
            all(type(code) is int and code == 0 for code in gates.values()), "One combined gate failed")
    offline = read_json(voice / "offline-uid.json")
    require(offline.get("package") == "org.zapime.android" and type(offline.get("uid")) is int and
            offline["uid"] >= 10000 and all(offline.get(k) is True for k in
                                           ("ipv4_reject", "ipv6_reject", "removed")),
            "Missing verified per-UID IPv4/IPv6 isolation or exact-rule cleanup")
    return {
        "schema_version": 1, "status": "PASS", "verification_kind": "offline_retained_report_replay",
        "provenance": {"repository": "ForceMind/ZapIME", "run_id": RUN, "job_id": JOB,
                       "artifact_id": ARTIFACT, "head_sha": HEAD, "checkout_sha": CHECKOUT, "tree_sha": TREE,
                       "job_url": f"https://github.com/ForceMind/ZapIME/actions/runs/{RUN}/job/{JOB}"},
        "integrity": {"original_zip_bytes": ZIP_BYTES, "original_zip_sha256": ZIP_SHA,
                      "original_zip_rehashed": True, "original_members_verified": 91,
                      "original_member_bytes": total, "zip_and_extracted_members_byte_equal": True,
                      "download_manifest_sha256": sha((base / "download-manifest.json").read_bytes())},
        "pinned_source_sha256": SOURCE_HASHES, "executed_pure_json_block_sha256": block_sha,
        "tools_contract": {"fixed_total_budget_ms": 8000, "required_samples": 10,
                           "required_stable_window_ms": 500,
                           "original_host_served_focus_insets_and_animation_bracket_required": True,
                           "both_tool_node_identities_and_geometry_required": True,
                           "real_letters_or_changed_host_immediately_rejected": True,
                           "missing_or_inconsistent_samples_reset_proof": True,
                           "scope": "Contract of pinned executed source; individual observed counts/timings were not retained."},
        "keyboard_rounds": rounds,
        "voice": {"status": "PASS", "native": native, "strict_reports": reports,
                  "native_acceptance_marker": True, "actual_emulator_voice_ui_marker": True,
                  "empty_result_insert_checked": True, "no_app_fatal": True,
                  "actual_exit": verify_keyboard_and_exit(voice, "ime-teardown.txt"),
                  "voicekey_scope": "Only 5 JNI boundary/ownership cases here; model_decode_executed=false."},
        "offline_voice_text_cleanup": {"installed_test_passed": True,
                                       "local_opt_in_preference_restored": True,
                                       "scope": "Synthetic installed deterministic cleaner; no live IME cleanup or semantic-rewrite claim."},
        "offline_uid_isolation_and_cleanup": offline,
        "combined_gate_exit_codes": gates,
        "limitations": [
            "API36 x86_64 ephemeral emulator evidence; no handset or natural-speech accuracy acceptance.",
            "Full final PASS follows mandatory tools/privacy/input assertions; early tools events were evicted from the bounded 64-entry driver log.",
            "Observed tools sample counts and stabilization times remain null; source thresholds are not reported as measured values.",
            "Permission-state confirmation cases simulate ContextWrapper states; they do not prove OS permission revocation behavior.",
            "Local account/backup/sync-preparation fixtures do not prove Android HTTPS success or cross-device sync.",
            "This replay performs no new on-device test, installation, cleanup or network request.",
        ],
    }


BASE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=BASE.parent / "ZapIME")
    args = parser.parse_args()
    try:
        report = verify(BASE, args.repo)
        lines = [
            "PASS original ZIP bytes/SHA256 and all 91 original member bytes/SHA256",
            "PASS two full API36 input/privacy rounds and mandatory tools restart path",
            "INFO per-sample tools counts/timings not retained; source thresholds are not measured results",
            "PASS original strict native JSON predicates: 6/23/7/5/11/8/5 cases",
            "PASS actual native X-ASR decode and emulator microphone UI; empty-result insert checked",
            "PASS all three actual switches to a verified system keyboard and empty service dumps",
            "PASS installed deterministic voice cleanup with restored local opt-in preference",
            "PASS product UID IPv4+IPv6 rejection and verified rule removal",
            "PASS keyboard-repeat and voice gate exit codes are both zero",
        ]
        exit_code = 0
    except (Exception, SystemExit) as error:
        report = {"schema_version": 1, "status": "FAIL", "error": str(error),
                  "verification_kind": "offline_retained_report_replay"}
        lines = ["FAIL " + str(error)]
        exit_code = 1
    report["replay_script_sha256"] = sha(Path(__file__).read_bytes())
    output = "\n".join(lines) + "\n"
    (BASE / "verification.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (BASE / "verification-output.txt").write_text(output, encoding="utf-8")
    print(output, end="")
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
