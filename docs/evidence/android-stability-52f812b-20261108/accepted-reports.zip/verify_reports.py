#!/usr/bin/env python3
"""Read-only replay of pinned ZapIME report validators; no ADB or network."""
import hashlib
import json
from pathlib import Path
import re
import sys
import textwrap

ROOT = Path(__file__).resolve().parent
SNAPSHOT = ROOT / 'validator-snapshot'
sys.path.insert(0, str(SNAPSHOT / 'scripts'))
from android_candidate_ranking_report import verify_report as candidate
from android_candidate_ranking_smoke import verify_restart_methods
from android_candidate_ime_smoke import verify_report as candidate_ime
from android_configuration_compose_report import verify_configuration_report
from android_voicekey_model_smoke import verify_reports, verify_boundary_report, verify_watchdog_report, verify_permission_cases
from voicekey_cpu_probe import trusted_lock
from android_sync_preparation_report import verify_report as preparation, verify_ui_report as recovery_ui
from android_sync_key_report import verify_report as key_registration
from android_sync_transfer_report import verify_report as transfer
from android_sync_pages_report import verify_report as pages
from android_sync_https_report import verify_report as https
from android_sync_https_smoke import verify_fixture_summary

RESULTS = []
def check(name, function, detail=None):
    try:
        function()
        RESULTS.append(dict(name=name, status='PASS', detail=detail))
    except BaseException as error:
        RESULTS.append(dict(name=name, status='FAIL', error=type(error).__name__ + ': ' + str(error)))

def get(path):
    def unique(items):
        value={}
        for k,v in items:
            if k in value: raise ValueError('duplicate report key: '+k)
            value[k]=v
        return value
    return json.loads(path.read_text(), object_pairs_hook=unique)

def require(value, message):
    if not value: raise AssertionError(message)

def artifact(aid):
    return ROOT / ('artifact-'+str(aid))

def uid(path):
    report=get(path)
    require(report.get('package')=='org.zapime.android', 'wrong product UID binding')
    require(type(report.get('uid')) is int and report['uid']>=10000, 'invalid UID')
    require(all(report.get(k) is True for k in ('ipv4_reject','ipv6_reject','removed')), 'network rejection/cleanup incomplete')

def teardown(path):
    require(path.is_file(), 'no teardown evidence')
    require('ZapInputMethodService' not in path.read_text(), 'product service still present')

def system_keyboard(path, api):
    r=get(path)
    require(r.get('api_level')==api and r.get('system_package_verified') is True and r.get('source')=='pm list packages -s', 'system IME identity unverified')
    require(isinstance(r.get('selected_ime'),str) and '/' in r['selected_ime'] and not r['selected_ime'].startswith('org.zapime.android'), 'bad exit IME')
    if api==28: require(r.get('aosp') is True, 'API28 AOSP exit not proven')

def clean_errors(path):
    for n in ('crash.txt','activity-errors.txt','runtime-errors.txt','runtime-errors.log'):
        p=path/n
        if not p.exists():continue
        s=p.read_text()
        require(not ('org.zapime.android' in s and any(x in s for x in ('FATAL EXCEPTION','Fatal signal','ANR in org.zapime.android'))), 'product fatal/ANR in '+n)

def run_summary(path, token, api):
    r=get(path)
    require(r.get('run_attempt')==token and r.get('api_level')==api, 'wrong run identity')
    require(all(r.get(k) is True for k in ('passed','instrumentation_verified','system_keyboard_restored','service_exited','settings_restored','offline_uid_verified')), 'missing system proof')
    require(r.get('errors')==[], 'system gate errors')
    for k in ('initial_data_clear','final_data_clear'):
        require(r.get(k)=={'org.zapime.android':True,'org.zapime.android.test':True}, 'incomplete owned cleanup')

for api,aid in [(28,13631968958),(35,13633110659),(36,13632472954)]:
    p=artifact(aid);method=p/'candidate-ranking-android';ime=p/'candidate-ime-android'
    check(f'candidate-api{api}-14-methods',lambda m=method,a=api:candidate(get(m/'candidate-ranking-report.json'),a),{'cases':14,'artifact_id':aid})
    if api>=31:
        check(f'candidate-api{api}-7-restart-editable-helpers',lambda m=method,a=api:verify_restart_methods(get(m/'verified-restart-method-report.json'),a),{'cases':7,'scope':'Unattached Service helper/Android Editable; full system configuration separate'})
    check(f'candidate-api{api}-system-ime',lambda i=ime,a=api:candidate_ime(get(i/'candidate-ime-report.json'),'42517974445-1',a))
    def candidate_cleanup(p=p,m=method,i=ime,a=api):
        summary=get(p/'candidate-suite-summary.json')
        require(summary.get('passed') is True and summary.get('completed') is True and summary.get('errors')==[] and summary.get('run_attempt')=='42517974445-1','suite did not pass')
        stages=summary.get('stages')
        require(len(stages)==2 and [s['name'] for s in stages]==['method','system-ime'],'suite stages missing')
        require(all(s.get('status')=='completed' and s.get('exit_code')==0 and s.get('passed') is True for s in stages),'suite child failure')
        run_summary(i/'run-summary.json','42517974445-1',a)
        uid(m/'offline-uid.json');uid(i/'offline-uid.json');teardown(i/'ime-teardown.txt');system_keyboard(i/'system-keyboard.json',a)
        clean_errors(m);clean_errors(i)
    check(f'candidate-api{api}-suite-exit-and-uid-cleanup',candidate_cleanup)

def configuration():
    p=artifact(13632891266)
    verify_configuration_report(get(p/'configuration-compose-report.json'),'42517974445-1',35)
    run_summary(p/'run-summary.json','42517974445-1',35)
    uid(p/'offline-uid.json');teardown(p/'ime-teardown.txt');system_keyboard(p/'system-keyboard.json',35);clean_errors(p)
check('configuration-api35-same-editor-composition-and-cleanup',configuration)

LOCK,_=trusted_lock(SNAPSHOT/'third_party/voicekey-model-lock.json')
voice_rows=[('focused',28,13632132951),('focused',35,13632886018),('focused',36,13632920300),('full',28,13632656445),('full',36,13632314559)]
extra=ROOT/'rerun-artifact.json'
if extra.exists():voice_rows.append(('full-attempt2',35,get(extra)['artifact_id']))
for suite,api,aid in voice_rows:
    p=artifact(aid)/'voicekey-android'
    def voice(p=p,api=api):
        model=get(p/'voicekey-model-report.json');commit=get(p/'voice-commit-report.json')
        verify_reports(model,commit,LOCK);verify_boundary_report(get(p/'voicekey-boundary-report.json'))
        watchdog=get(p/'voicekey-watchdog-report.json');verify_watchdog_report(watchdog,LOCK)
        require(next(c for c in model['cases'] if c['id']=='actual_android_stop_watchdog')==watchdog,'watchdog independent report differs')
        require(model.get('api_level')==api,'model API mismatch')
        summary=get(p/'acceptance-summary.json')
        require(summary.get('status')=='PASS' and summary.get('saf_jni_editable')=='PASS' and summary.get('activated_system_ime_and_emulator_audio_record')=='PASS','voice acceptance incomplete')
        require(all(summary.get(k) is True for k in ('actual_ime_service_exit','emulator_soft_keyboard_policy_restored','shared_document_removed')),'voice cleanup incomplete')
        require(summary.get('model_weights_uploaded') is False and summary.get('natural_speech')=='NOT RUN' and summary.get('phone_and_arm')=='NOT RUN','voice scope inflated')
        for name,marker in [('model-instrumentation.txt','PASS Android VoiceKey official model acceptance'),('ime-instrumentation.txt','PASS ZapIME voice UI:')]:
            s=(p/name).read_text();require(marker in s and 'INSTRUMENTATION_CODE: -1' in s and 'FAIL Android voice' not in s and 'INSTRUMENTATION_FAILED' not in s,'voice instrumentation failure')
        uid(p/'offline-uid.json');teardown(p/'ime-teardown.txt');system_keyboard(p/'system-keyboard.json',api);clean_errors(p)
    check(f'voicekey-{suite}-api{api}-37-model-and-editable-plus-5-boundaries',voice,{'model_cases':14,'confirmation_cases':23,'jni_boundary_cases':5,'artifact_id':aid})

for api,aid in [(28,13632611264),(35,13632586869),(36,13632736777)]:
    p=artifact(aid)
    checks=[('sync-preparation-report.json',preparation),('sync-preparation-ui-report.json',recovery_ui),('sync-key-registration-report.json',key_registration),('sync-transfer-report.json',transfer),('sync-pages-ui-report.json',pages)]
    for name,validator in checks:
        check(f'sync-api{api}-{name}',lambda p=p,n=name,v=validator,a=api:v(get(p/n),a),{'cases':len(get(p/name)['cases']),'artifact_id':aid})
    check(f'sync-api{api}-uid-and-runtime',lambda p=p:(uid(p/'offline-uid.json'),clean_errors(p)))

def https_checks():
    p=artifact(13632262421)
    for phase in ('before','roundtrip','after'):
        https(get(p/f'sync-https-{phase}-report.json'),phase,28)
        execution=get(p/f'sync-https-{phase}-execution.json')
        require(execution==dict(phase=phase,status='PASS',exception_type=None,returncode=0),'HTTPS phase did not execute')
    d=get(p/'sync-https-driver-report.json');verify_fixture_summary(d['fixture'])
    require(d.get('status')=='PASS' and d.get('api_level')==28 and d.get('cleanup_completed') is True and d.get('owned_packages_removed') is True,'HTTPS driver incomplete')
    require(all(d['ca'].get(k) is True for k in ('installed','removed','staging_removed','baseline_restored')),'CA baseline not restored')
    require(all(d['network'].get(k) is True for k in ('ipv4_fixture_only','ipv6_reject','removed')),'HTTPS UID boundary incomplete')
    require(d.get('ca_cleanup_exception_types')==[] and d.get('package_cleanup_exception_types')==[],'HTTPS cleanup failed')
    require(d.get('api35_36')=='BLOCKED_NOT_RUN' and d.get('product_trust_code_changed') is False,'HTTPS scope inflated')
check('actual-android-https-api28-3-phases-go-postgresql-and-cleanup',https_checks,{'phase_cases':14,'artifact_id':13632262421})

# Execute only the repository's existing pure report-validation block, never
# android_voice_smoke's top-level ADB orchestration or setup.
source=(SNAPSHOT/'scripts/android_voice_smoke.py').read_text()
report_block=textwrap.dedent(source[source.index('    evidence=json.loads'):source.index('    method="org.zapime.android/.ZapInputMethodService"')])
for api,aid in [(28,13632357194),(35,13632114246),(36,13632133976)]:
    p=artifact(aid);voice=p/'voice-android'
    def full_android(p=p,voice=voice,api=api):
        require(get(voice/'combined-gates.json')=={'android_smoke_repeat.py':0,'android_voice_smoke.py':0},'combined native gates failed')
        exec(compile(report_block,'pinned android_voice_smoke.py report-only block','exec'),dict(json=json,out=voice,verify_permission_cases=verify_permission_cases,verify_boundary_report=verify_boundary_report,verify_sync_preparation=preparation))
        native=get(voice/'native-report.json')
        require(native.get('synthetic') is True and native.get('api_level')==api and native.get('expected_fragments_passed') is True and native.get('recognized_codepoints',0)>0,'native decode evidence missing')
        for name,marker in [('instrumentation.txt','PASS Android offline voice native acceptance'),('ui-instrumentation.txt','PASS ZapIME voice UI:')]:
            s=(voice/name).read_text();require(marker in s and 'INSTRUMENTATION_CODE: -1' in s and 'FAIL Android voice' not in s and 'INSTRUMENTATION_FAILED' not in s,'full Android instrument failure')
        uid(voice/'offline-uid.json');teardown(voice/'ime-teardown.txt');system_keyboard(voice/'system-keyboard.json',api);clean_errors(voice)
        for number in (1,2):
            r=p/'device-smoke-evidence/42517974761-1'/f'round-{number}'
            s=(r/'instrumentation.log').read_text();require(s.startswith('PASS ZapIME native keyboard:') and 'FAIL ZapIME' not in s,'keyboard round failed')
            teardown(r/'ime-teardown.log');system_keyboard(r/'system-keyboard.json',api);clean_errors(r)
    check(f'full-android-api{api}-two-keyboard-rounds-native-voice-backup-sync-and-cleanup',full_android,{'artifact_id':aid,'report_validation':'Exact pure report block from pinned source plus original instrument/teardown/UID evidence'})

def identity():
    r=get(ROOT/'source-identity.json')
    require(r['same_tree'] is True and r['pr_head']['tree']==r['checkout']['tree']=='2c73b5abe92214ad97eb0104f11911fa6a9d3cb6','not exact tree')
    for aid,name in [(13632157533,'candidate-ranking-build.json'),(13631894581,'voicekey-focused-build.json')]:
        m=get(artifact(aid)/name)
        require(m.get('source_commit')==r['checkout']['sha'] and m.get('status')=='BUILT','build checkout differs')
check('exact-pr-head-and-checkout-tree-build-identity',identity)

report=dict(source_commit='52f812bc269f35ba636997b9c4664c2b83a22154',checks=RESULTS,passed=all(x['status']=='PASS' for x in RESULTS),limitations=['Report replay is independent revalidation of retained CI evidence, not new device execution.','Seven restart Editable helpers apply only to API31+, run on API35/36; API28 is not claimed.','Complete Android API28 reports were independently extracted from its SHA256-verified mixed 248741116-byte artifact; APKs and PCM are omitted from the evidence bundle.','Candidate/focused APK hashes are build metadata; their separate binaries were not independently downloaded.','Phone/ARM/natural voice/signing/other-platform system input remain unaccepted.'])
(ROOT/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for x in RESULTS:print(x['status'],x['name'],x.get('error',''))
raise SystemExit(0 if report['passed'] else 1)
